use std::error::Error;
use std::fs::File;
use std::io::BufReader;

use csv::Reader;
use statrs::statistics::correlation::pearson;

fn main() -> Result<(), Box<dyn Error>> {
    let file = File::open("2019_games.csv")?;
    let reader = Reader::from_reader(BufReader::new(file));

    let mut x = Vec::new();
    let mut y = Vec::new();

    for result in reader.records() {
        let record = result?;
        let x_val: f64 = record[5].parse()?; //whether or not it is a home team
        let y_val: f64 = record[6].parse()?; //whether or not it is a win
        x.push(x_val);
        y.push(y_val);
    }

    let correlation = pearson(&x, &y);

    println!("The Pearson's correlation coefficient is {}", correlation);

    Ok(())
}





