use csv::Reader;
use std::fs::File;
use std::error::Error;

fn main() -> Result<(), Box<dyn Error>> {
    let wins = wins;
    let losses = losses;
    let mut rdr = Reader::from_path("2019_games.csv")?;
    for result in rdr.records() {
        let record = result?;
        let a: i32 = record[3].parse()?;
        let b: i32 = record[4].parse()?;
        match a.cmp(&b) {
            Ordering::Less => losses = losses + 1,
            Ordering::Greater => wins = wins + 1,
        }
    }
    Ok(())

    println!("Probability of home team winning: {}", wins/162);
    println!("Probability of home away winning: {}", losses/162);

}
